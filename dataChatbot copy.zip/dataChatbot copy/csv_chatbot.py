import pandas as pd

class CSVChatbot:
    def __init__(self, csv_path):
        self.df = pd.read_csv(csv_path)

    def get_columns(self):
        return list(self.df.columns)

    def preview_data(self):
        return self.df.head(3).to_string(index=False)

    def get_full_data(self):
        return self.df.to_string(index=False)
