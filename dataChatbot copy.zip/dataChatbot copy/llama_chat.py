import subprocess

def ask_llama(prompt):
    result = subprocess.run(
        [
            "ollama", "run", "llama3"
        ],
        input=prompt,
        capture_output=True,
        text=True
    )
    return result.stdout.strip()
