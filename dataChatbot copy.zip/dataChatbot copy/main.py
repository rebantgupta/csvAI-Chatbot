from flask import Flask, render_template, request, session
from csv_chatbot import CSVChatbot
from llama_chat import ask_llama

app = Flask(__name__)
app.secret_key = "secretkey123"  # Needed to use sessions

chatbot = CSVChatbot("Sanitized_West_Zone_Data.csv")

@app.route("/", methods=["GET", "POST"])
def chat():
    if "history" not in session:
        session["history"] = []

    if request.method == "POST":
        user_input = request.form["user_input"]
        
        conversation = "\n".join(
            [f"User: {msg['user']}\nBot: {msg['bot']}" for msg in session["history"]]
        )

        prompt = (
            f"You are a helpful data assistant. The CSV columns are:\n"
            f"{', '.join(chatbot.get_columns())}\n\n"
            f"Here is the full data:\n{chatbot.get_full_data()}\n\n"
            f"User: {user_input}\nBot:"
        )


        bot_response = ask_llama(prompt)

        # Save exchange
        session["history"].append({"user": user_input, "bot": bot_response})
        session.modified = True

    return render_template("index.html", history=session["history"])


@app.route("/reset")
def reset():
    session.clear()
    return "Chat history cleared. <a href='/'>Go back</a>"
